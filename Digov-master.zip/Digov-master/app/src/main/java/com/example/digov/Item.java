package com.example.digov;

public class Item {


    String Item;
    int Price;

    public Item(String item , int price) {
        Item = item;
        Price = Price;
    }
    public String toString() {
        return Item ;
    }

    public String getItem() {
        return Item;
    }

    public void setItem(String item) {
        Item = item;
    }

    public int getPrice() {
        return Price;
    }

    public void setPrice(int price) {
        Price = price;
    }


}

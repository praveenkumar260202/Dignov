# Digov
Problem statement:
In this fast-growing world, it is very tough to shop things in adequate time. One
of the problems like queuing in Bill counter which leads to wastage of our
precious time.
Objective:
Our task is to solve the above-mentioned problem through virtual store. To
make virtual store, we are going to attach sheets with photo and QR-code of
products in public places. When people scan QR-code, they can able to buy
products through the online which leads to reduce crowd in grocery stores, super
markets, shopping malls.
Tools & Software:
1) Language: Java, XML.
2) IDE: Android Studio.
3) Version Control: Git
4) Backend: Firebase
